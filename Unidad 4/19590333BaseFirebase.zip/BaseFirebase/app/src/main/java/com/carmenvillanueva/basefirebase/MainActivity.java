package com.carmenvillanueva.basefirebase;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;
public class MainActivity extends AppCompatActivity {
    private EditText nombre, color, codigo, precio;
    private DatabaseReference db_prod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText) findViewById(R.id.nombre);
        color = (EditText) findViewById(R.id.color);
        codigo = (EditText) findViewById(R.id.codigo);
        precio = (EditText) findViewById(R.id.precio);
        db_prod = FirebaseDatabase.getInstance().getReference();
    }
    public void Alta_prod (View view){
        String nombreS = nombre.getText().toString();
        String usoS = color.getText().toString();
        double codigo1 = Double.parseDouble(codigo.getText().toString());
        long precio_prod = Long.parseLong((precio.getText().toString()));
        try {
            Map<String, Object> datosProd = new HashMap<>();
            datosProd.put("nombre",nombreS);
            datosProd.put("color",usoS);
            datosProd.put("codigo1",codigo1);
            datosProd.put("precio",precio_prod);
            db_prod.child("Productos").child(nombreS).setValue(datosProd);
            Toast.makeText(this,"Registro Exitoso",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(this,"Hubo un problema",Toast.LENGTH_SHORT).show();
        }
    }
    public void Baja_prod (View view){
        String nombreS = nombre.getText().toString();
        try {
            DatabaseReference drProducto =
                    FirebaseDatabase.getInstance().getReference("Productos").child(nombreS);
            drProducto.removeValue();
            Toast.makeText(this,"Baja exitosa", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
Toast.makeText(this,"Hubo un problema",Toast.LENGTH_SHORT).show();
        }
        }
public void Modificar_prod (View view){
        String nombreS = nombre.getText().toString();
        String usoS = color.getText().toString();
        double codigo1= Double.parseDouble(codigo.getText().toString());
        long precio1 = Long.parseLong((precio.getText().toString()));
        try {
        Map<String, Object> datosProdMod = new HashMap<>();
        datosProdMod.put("nombre",nombreS);
        datosProdMod.put("color",usoS);
        datosProdMod.put("codigo",codigo1);
        datosProdMod.put("precio_prod",precio1);
        DatabaseReference mdProducto =
        FirebaseDatabase.getInstance().getReference("Productos").child(nombreS);
        mdProducto.updateChildren(datosProdMod);
        Toast.makeText(this, "Cambio Exitoso", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
        Toast.makeText(this, "Hubo un problema", Toast.LENGTH_SHORT).show();
        }
        }
        }