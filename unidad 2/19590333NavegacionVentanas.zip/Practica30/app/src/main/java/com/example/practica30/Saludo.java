package com.example.practica30;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Saludo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);
    }
    public void R (View view)
    {
        Intent frut = new Intent(Saludo.this,MainActivity.class);
        startActivity(frut);
    }
    public void ir (View view)
    {
        Intent frut = new Intent(Saludo.this,v3.class);
        startActivity(frut);
    }

}