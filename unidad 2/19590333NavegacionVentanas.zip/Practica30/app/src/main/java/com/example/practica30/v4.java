package com.example.practica30;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class v4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_v4);
    }
    public void prueba (View view)
    {
        Intent frut = new Intent(v4.this,v3.class);
        startActivity(frut);
    }
}