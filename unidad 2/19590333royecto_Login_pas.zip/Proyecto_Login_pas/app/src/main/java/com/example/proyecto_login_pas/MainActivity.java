package com.example.proyecto_login_pas;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button b1, b2;
    String nombre = "Carmen villanueva", loging = "Carmen", pass = "1510";
    private EditText log, pas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log = findViewById(R.id.usuario);
        pas = findViewById(R.id.clave);
    }

    public void validar(View view) {

        String l = log.getText().toString();
        String p = pas.getText().toString();

        if (l.equals(loging) && (p.equals(pass))) {
            Toast.makeText(this, "Bienvenido Administrador", Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this, "Clave no valida", Toast.LENGTH_LONG).show();
        }

    }

    public void limpiar(View view) {
        log.setText(" ");
        pas.setText(" ");
    }
}
