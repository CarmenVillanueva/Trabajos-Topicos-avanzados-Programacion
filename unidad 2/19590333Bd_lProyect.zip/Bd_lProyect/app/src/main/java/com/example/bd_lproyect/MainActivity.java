package com.example.bd_lproyect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.ed1);
        ed2=findViewById(R.id.ed2);
        ed3=findViewById(R.id.ed3);
        ed4=findViewById(R.id.ed4);
    }
    public void altas(View view )
    {
        AdminSQLiteOpenHelper admin= new AdminSQLiteOpenHelper(this,"administracion",null,1);//crear tabla ,informacion para base de datos
        SQLiteDatabase bd = admin.getWritableDatabase();
        String dni= ed1.getText().toString();//nControl
        String nombre=ed2.getText().toString();
        String nombreC=ed3.getText().toString();
        String Tipo=ed4.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("dni",dni);
        registro.put("nombre",nombre);
        registro.put("nombreC",nombreC);
        registro.put("Tipo",Tipo);
        bd.insert("usuario",null,registro);
        bd.close();
        Toast.makeText(this,"Datos de la planta cargados",Toast.LENGTH_SHORT).show();
        this.limpiar();
    }
    public void limpiar()
    {
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
    }
    public void limpiar(View view)
    {
        this.limpiar();
    }
    // Hacemos búsqueda de usuario por DNI
    public void consulta(View view)
    {
        AdminSQLiteOpenHelper admin= new AdminSQLiteOpenHelper(this,"administracion",null,1);
        SQLiteDatabase bd =admin.getWritableDatabase();
        String dni=ed1.getText().toString();
        Cursor fila = bd.rawQuery("select nombre,nombreC,Tipo from usuario where dni="+ dni,null);
        //Cursor fila = bd.rawQuery("select nombre,semestre,carrera from usuario" ,null);
        if(fila.moveToFirst())
        {

            //Toast.makeText(this, "Estoy dentro del registro ", Toast.LENGTH_SHORT).show();
            ed2.setText(fila.getString(0));
            ed3.setText(fila.getString(1));
            ed4.setText(fila.getString(2));
        }
        else
        {
            Toast.makeText(this, "No existe ninguna planta con ese dni", Toast.LENGTH_SHORT).show();
            bd.close();
        }
    }
    // Método para dar de baja al usuario insertado
    public void baja(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String dni = ed1.getText().toString();
        int cant = bd.delete("usuario", "dni=" + dni, null);//
        bd.close();
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed4.setText("");
        if (cant == 1)
            Toast.makeText(this, "Planta eliminada", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "No existe planta", Toast.LENGTH_SHORT).show();
    }
    // Método para modificar la información del usuario
    public void modificacion(View view) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();
        String dni = ed1.getText().toString();
        String nombre = ed2.getText().toString();
        String nombreC = ed3.getText().toString();
        String Tipo = ed4.getText().toString();
        ContentValues registro = new ContentValues();
        // actualizamos con los nuevos datos, la información cambiada
        registro.put("nombre", nombre);
        registro.put("nombreC", nombreC);
        registro.put("Tipo", Tipo);
        int cant = bd.update("Usuario", registro, "dni=" + dni, null);
        bd.close();
        if (cant == 1)
            Toast.makeText(this, "Datos modificados con éxito", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "No existe planta", Toast.LENGTH_SHORT).show();
    }


}