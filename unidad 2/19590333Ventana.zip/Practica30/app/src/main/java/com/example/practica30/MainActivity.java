//Programa de saludo desarrollado por: Maria Del Carmen Villanueva Martinez 24_agosto_2022
package com.example.practica30;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText nombre;
    private Button bNombre;
    private TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre=(EditText) findViewById(R.id.nombre);
        bNombre=(Button) findViewById(R.id.bNombre);
        resultado=(TextView) findViewById(R.id.resultado);
    }

     public void limpiar(View view)
     {
         nombre.setText("");
         resultado.setText("");
     }
    //aqui se construyen los metodos que se van a utilizar
    public void saludo (View view)
    {
        String n;
        n=nombre.getText().toString();
        resultado.setText("Hola "+n+" Como estas ");
    }
    public void prueba (View view)
    {
        Intent frut = new Intent(MainActivity.this,Saludo.class);
        startActivity(frut);
    }
}