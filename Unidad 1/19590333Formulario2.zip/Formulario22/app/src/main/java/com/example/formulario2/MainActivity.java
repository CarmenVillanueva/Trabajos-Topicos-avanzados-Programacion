package com.example.formulario2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button bnLimpio;
    private Button bnRegistro;

    private EditText nombre;
    private EditText appat;
    private EditText apmat;
    private EditText cP;
    private EditText cOl;
    private EditText cAlle;
    private EditText eDo;
    private EditText mUni;

    private TextView rNombre;
    private TextView rApMat;
    private TextView rApPat;
    private TextView rCP;
    private TextView rCol;
    private TextView rCalle;
    private TextView rEdo;
    private TextView rMuni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bnLimpio=(Button) findViewById(R.id.bnLimpio);
        bnRegistro=(Button) findViewById(R.id.bnRegistro);

        nombre=(EditText)findViewById(R.id.nombre);
        appat=(EditText)findViewById(R.id.apellidoP);
        apmat=(EditText)findViewById(R.id.apmat);
        cP=(EditText)findViewById(R.id.cp);
        cOl=(EditText)findViewById(R.id.col);
        cAlle=(EditText)findViewById(R.id.calle);
        eDo=(EditText)findViewById(R.id.edo);
        mUni=(EditText)findViewById(R.id.muni);


        rNombre=(TextView) findViewById(R.id.rNombre);
        rApMat=(TextView) findViewById(R.id.rApMat);
        rApPat=(TextView) findViewById(R.id.rApPat);
        rCP=(TextView) findViewById(R.id.rCP);
        rCol=(TextView) findViewById(R.id.rCol);
        rCalle=(TextView) findViewById(R.id.rCalle);
        rEdo=(TextView) findViewById(R.id.rEdo);
        rMuni=(TextView) findViewById(R.id.rMuni);
    }

    public void Registro(View view){

        String n,apep,apem,cp,colonia,calle,estado,municipio;
        n=nombre.getText().toString();
        apep =appat.getText().toString();
        apem=apmat.getText().toString();
        cp=cP.getText().toString();
        colonia=cOl.getText().toString();
        calle=cAlle.getText().toString();
        estado=eDo.getText().toString();
        municipio=mUni.getText().toString();

        rNombre.setText(n);
        rApPat.setText(apep);
        rApMat.setText(apem);
        rCP.setText(cp);
        rCol.setText(colonia);
        rCalle.setText(calle);
        rEdo.setText(estado);
        rMuni.setText(municipio);

    }
    public void limpiar(View view){
        nombre.setText("");
        appat.setText("");
        apmat.setText("");
        cP.setText("");
        cOl.setText("");
        cAlle.setText("");
        eDo.setText("");
        mUni.setText("");

        rNombre.setText("");
        rApPat.setText("");
        rApMat.setText("");
        rCP.setText("");
        rCol.setText("");
        rCalle.setText("");
        rEdo.setText("");
        rMuni.setText("");

    }

}